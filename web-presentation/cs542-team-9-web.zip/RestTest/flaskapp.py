from flask import Flask, render_template, session, redirect, url_for, flash, request
from flask_script import Manager
from flask_bootstrap import Bootstrap
from flask_moment import Moment
from flask_wtf import Form
from wtforms import StringField, IntegerField, RadioField, SubmitField, SelectField
from wtforms.validators import Required, NumberRange
import mysql.connector
import pandas as pd



access_token = '170909756591306|0Crp0iDzlsPF-z_cIo0eGMFH2ek'
mysqlUser='root'
mysqlPass='Haiyan1922;'

def get_all_business():
    sql = "select * from fb_business"
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')
    df = pd.read_sql_query(sql, cnx)
    df=df.T
    cnx.close()

    d = [
        dict([
                 (colname, row[i])
                 for i, colname in enumerate(df.columns)
                 ])
        for row in df.values
        ]
    return json.dumps(d)
    #return df.to_json(orient='split')

def get_business_total_like():
    sql = "SELECT business, like_count FROM mydb.fb_business_total_like where date=(select max(date) from fb_business_total_like)"
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')
    df = pd.read_sql_query(sql, cnx)
    cnx.close()

    return df.to_json(orient='columns')
    #return df.T.to_json()

def get_business_summary(business):
    sql = "SELECT DATE_FORMAT(date, '%Y-%m-%d') as date, like_count FROM mydb.fb_business_total_like where business=" + business
    sql=sql+"order by date"
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')
    df = pd.read_sql_query(sql, cnx)
    df=df
    cnx.close()
    return df.to_json(orient='columns')

def get_twitter_business_summary(business):
    sql = "SELECT DATE_FORMAT(date, '%Y-%m-%d') as date, tweets_count,followers_count, following_count FROM mydb.twitter_business_total where business=" + business
    sql=sql+"order by date"
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')
    df = pd.read_sql_query(sql, cnx)
    df=df
    cnx.close()
    return df.to_json(orient='columns')

def get_fb_post_summary(business):
    sql = "SELECT DATE_FORMAT(created_dt, '%Y-%m') as Month, count(*) as count FROM mydb.fb_posts where business=" + business
    sql=sql+" group by DATE_FORMAT(created_dt, '%Y-%m')"
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')
    df = pd.read_sql_query(sql, cnx)
    df=df
    cnx.close()
    return df.to_json(orient='columns')

def get_fb_post_shared_summary(business):
    sql = "SELECT DATE_FORMAT(date, '%Y-%m') as Month, count(*) as count FROM mydb.fb_post_shared where business=" + business
    sql = sql + " group by DATE_FORMAT(date, '%Y-%m')"
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')
    df = pd.read_sql_query(sql, cnx)
    df=df
    cnx.close()
    return df.to_json(orient='columns')

def get_fb_post_comment_summary(business):
    sql = "SELECT DATE_FORMAT(created_dt, '%Y-%m') as Month, count(*) as count FROM mydb.fb_post_comments where business=" + business
    sql = sql + " group by DATE_FORMAT(created_dt, '%Y-%m')"

    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')
    df = pd.read_sql_query(sql, cnx)
    df=df
    cnx.close()
    return df.to_json(orient='columns')


def get_fb_post_sentiment_summary(business):
    sql = "SELECT date_format(date, '%Y-%m') as Month, avg(sentiment) sentiment from fb_business_sentiment where business="+business+" group by date_format(date, '%Y-%m')"


    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')
    df = pd.read_sql_query(sql, cnx)
    df=df
    cnx.close()
    return df.to_json(orient='columns')

def get_twitter_post_summary(business):
    sql = "SELECT DATE_FORMAT(created_dt, '%Y-%m-%d') as date, count(*) as count FROM mydb.twitter_tweets where business=" + business
    sql=sql+" group by DATE_FORMAT(created_dt, '%Y-%m-%d')"
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')
    df = pd.read_sql_query(sql, cnx)
    df=df
    cnx.close()
    return df.to_json(orient='columns')

def get_twitter_post_shared_summary(business):
    sql = "SELECT DATE_FORMAT(date, '%Y-%m-%d') as date, count(*) as count FROM mydb.twitter_tweets_shared where business=" + business
    sql = sql + " group by DATE_FORMAT(date, '%Y-%m-%d')"
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')
    df = pd.read_sql_query(sql, cnx)
    df=df
    cnx.close()
    return df.to_json(orient='columns')

def get_twitter_post_comment_summary(business):
    sql = "SELECT DATE_FORMAT(created_dt, '%Y-%m-%d') as date, count(*) as count FROM mydb.twitter_tweets_comments where business=" + business
    sql = sql + " group by DATE_FORMAT(created_dt, '%Y-%m-%d')"

    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')
    df = pd.read_sql_query(sql, cnx)
    df=df
    cnx.close()
    return df.to_json(orient='columns')
#get all competitors for a business
#the list is comma seperated with single quote
def get_all_competitors(business):
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')

    # do all the analysis with files
    cursor = cnx.cursor()

    sql = "Select competitors from fb_business where name=" + business
    cursor.execute(sql)
    total_names = ""
    for competitors in cursor:
        print competitors[0]
        business_array = competitors[0].split(",")
        length = 0
        for single_name in business_array:
            length = length + 1
            if (length == len(business_array)):
                total_names = total_names + "'" + single_name + "'"
            else:
                total_names = total_names + "'" + single_name + "',"
    cnx.close()
    return total_names

#get facebook's total post with all competitors
def get_fb_total_post_compare(business):
    total_names=get_all_competitors(business)
    sql="SELECT date_format(created_dt, '%Y-%m') as Month, Upper(Business) as Business, count(*) as count from fb_posts where business in ("
    sql=sql+ total_names + ")"
    sql=sql+" group by upper(business), date_format(created_dt, '%Y-%m')"
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')

    df = pd.read_sql_query(sql, cnx)

    # Pivot data into a new dataframe
    DF_pivot = df.pivot('Month', 'Business', 'count')
    cnx.close()
    return DF_pivot.to_json(orient='columns')

#get facebook's total like with all competitors
def get_fb_total_like_compare(business):
    total_names = get_all_competitors(business)
    sql="SELECT date_format(date, '%Y-%m') as Month, Upper(Business) as Business, sum(like_count) as count from fb_post_like where business in ("
    sql=sql+ total_names + ")"
    sql=sql+" group by upper(business), date_format(date, '%Y-%m')"
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')

    df = pd.read_sql_query(sql, cnx)

    # Pivot data into a new dataframe
    DF_pivot = df.pivot('Month', 'Business', 'count')
    cnx.close()
    return DF_pivot.to_json(orient='columns')



#get facebook's total comments with all competitors
def get_fb_total_comment_compare(business):
    total_names = get_all_competitors(business)
    sql="SELECT date_format(created_dt, '%Y-%m') as Month, Upper(Business) as Business, count(*) as count from fb_post_comments where business in ("
    sql=sql+ total_names + ")"
    sql=sql+" and created_dt>'2014-11-01' group by upper(business), date_format(created_dt, '%Y-%m')"
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')

    df = pd.read_sql_query(sql, cnx)

    # Pivot data into a new dataframe
    DF_pivot = df.pivot('Month', 'Business', 'count')
    cnx.close()
    return DF_pivot.to_json(orient='columns')



#get facebook's total comments with all competitors
def get_fb_total_sentiment_compare(business):
    total_names = get_all_competitors(business)
    sql="SELECT date_format(date, '%Y-%m') as Month, Upper(Business) as Business, avg(sentiment) as sentiment from "
    sql=sql+"fb_business_sentiment where business in ("
    sql=sql+ total_names + ")"
    sql=sql+" group by upper(business), date_format(date, '%Y-%m')"
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')

    df = pd.read_sql_query(sql, cnx)

    # Pivot data into a new dataframe
    DF_pivot = df.pivot('Month', 'Business', 'sentiment')
    cnx.close()
    return DF_pivot.to_json(orient='columns')



#get twitter's total post with all competitors
def get_twitter_total_post_compare(business):
    total_names=get_all_competitors(business)
    sql="SELECT date_format(created_dt, '%Y-%m') as Month, Upper(Business) as Business, count(*) as count from twitter_tweets where business in ("
    sql=sql+ total_names + ")"
    sql=sql+" group by upper(business), date_format(created_dt, '%Y-%m')"
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')

    df = pd.read_sql_query(sql, cnx)

    # Pivot data into a new dataframe
    DF_pivot = df.pivot('Month', 'Business', 'count')
    cnx.close()
    return DF_pivot.to_json(orient='columns')

#get twitter's total like with all competitors
def get_twitter_total_like_compare(business):
    total_names = get_all_competitors(business)
    sql="SELECT date_format(date, '%Y-%m') as Month, Upper(Business) as Business, sum(like_count) as count from twitter_tweets_like where business in ("
    sql=sql+ total_names + ")"
    sql=sql+" group by upper(business), date_format(date, '%Y-%m')"
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')

    df = pd.read_sql_query(sql, cnx)

    # Pivot data into a new dataframe
    DF_pivot = df.pivot('Month', 'Business', 'count')
    cnx.close()
    return DF_pivot.to_json(orient='columns')



#get twitter's total comments with all competitors
def get_twitter_total_comment_compare(business):
    total_names = get_all_competitors(business)
    sql="SELECT date_format(created_dt, '%Y-%m') as Month, Upper(Business) as Business, count(*) as count from twitter_tweets_comments where business in ("
    sql=sql+ total_names + ")"
    sql=sql+" and created_dt>'2014-11-01' group by upper(business), date_format(created_dt, '%Y-%m')"
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')

    df = pd.read_sql_query(sql, cnx)

    # Pivot data into a new dataframe
    DF_pivot = df.pivot('Month', 'Business', 'count')
    cnx.close()
    return DF_pivot.to_json(orient='columns')



#get twitter's total comments with all competitors
def get_twitter_total_sentiment_compare(business):
    total_names = get_all_competitors(business)
    sql = "select date_format(created_dt, '%Y-%m') as Month, business, avg(sentiment) as sentiment from("
    sql = sql + "SELECT tweets.created_dt,tweets.business, sentiment.comment_id,"
    sql = sql + "sentiment.sentiment FROM twitter_comment_sentiment sentiment,"
    sql = sql + "twitter_tweets_comments tweets where business in ("
    sql = sql + total_names + ")"
    sql=sql+" and sentiment.comment_id=tweets.comment_id) c group by (business), date_format(created_dt, '%Y-%m')"
    cnx = mysql.connector.connect(user=mysqlUser, password=mysqlPass, database='mydb')

    df = pd.read_sql_query(sql, cnx)

    # Pivot data into a new dataframe
    DF_pivot = df.pivot('Month', 'business', 'sentiment')
    cnx.close()
    return DF_pivot.to_json(orient='columns')


app = Flask(__name__)
app.config['SECRET_KEY'] = 'dhdhggdsjhgfjgyterewbejkdkdndhdhdgsbddddddd31415'
#app.debug = True
manager = Manager(app)
bootstrap = Bootstrap(app)
moment = Moment(app)

default_image_width = "120px"

image_width_small = "120px"
image_height_small = "200px"

image_width_large = "600px"
image_height_large = "600px"

main_menu = [('one', 'Analyze a Single Business'),
             ('market_fb', 'Market Analysis - Luxury Cars'),
             ('market_tw', 'Market Analysis - Retail'),
             ('all_fb', 'Analysis of Multiple Markets - Facebook'),
             ('all_tw', 'Analysis of Multiple Markets - Twitter'),
             ('cluster', 'Cluster Analysis of Social Media Posts'),
             ('networks', 'Relative Impact of Different Social Networks')]

business_list = [('bmw', 'BMW')]
# business_list = [('audi', 'Audi'), ('bmw','BMW'), ('mb','Mercedes-Benz'), ('lexus','Lexus'), ('jcp',"JC Penney's"),('target','Target'), ('visa','Visa'), ('mc','MasterCard'), ('amex','American Express')]

social_network_list = [('facebook', 'Facebook'),
                       ('twitter', 'Twitter')]

analysis_list = [('overview', 'Overview'),
                 ('mc', 'Most Commented'),
                 ('mp', 'Most Positive'),
                 ('mn', 'Most Negative')]

cluster_business_list = [('dunkin', 'Dunkin Donuts'), ('walmart', 'Walmart')]


#
class MainMenu(Form):
    scope = SelectField('Select Scope', choices=main_menu, validators=[Required()])
    submit = SubmitField('Next')


class NameForm(Form):
    name = SelectField('Business name?', choices=business_list, validators=[Required()])
    submit = SubmitField('Next')


class StartForm(Form):
    social_network = SelectField('Social Network?', choices=social_network_list, validators=[Required()])
    days = IntegerField('How far back do you want to look (days)?',
                        validators=[Required(),
                                    NumberRange(min=1, max=7, message='Please enter a integer between 1 and 7')])
    submit = SubmitField('Next')


class SelectAnalysis(Form):
    analysis_type = SelectField('Analysis', choices=analysis_list, validators=[Required()])
    submit = SubmitField('Next')


class SelectCluster(Form):
    cluster_business = SelectField('Business', choices=cluster_business_list, validators=[Required()])
    submit = SubmitField('Next')


@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404


@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500


@app.route('/', methods=['GET', 'POST'])
def main_menu():
    form = MainMenu()
    session['scope'] = form.scope.data
    # NOTE TO SELF - it would be simpler to align names in list with view function names and
    # then return redirect(url_for(session['scope']))
    if form.validate_on_submit():
        if session['scope'] == 'one':
            return redirect(url_for('one'))
        elif session['scope'] == 'market_fb':
            return redirect(url_for('markets'))
        elif session['scope'] == 'market_tw':
            return redirect(url_for('markets'))
        elif session['scope'] == 'networks':
            return redirect(url_for('networks'))
        elif session['scope'] == 'cluster':
            return redirect(url_for('cluster'))
        else:
            return redirect(url_for('charts'))
    return render_template('main_menu.html', form=form)

#@app.route('/')
#def hello_world():
 # return 'Hello from Flask!Really Still Works!'

@app.route('/chartTest', methods=['GET', 'POST'])
def get_chart():
    json_input=[{
    "name": "Month",
    "data": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
}, {
    "name": "Revenue",
    "data": [23987, 24784, 25899, 25569, 25897, 25668, 24114, 23899, 24987, 25111, 25899, 23221]
}, {
    "name": "Overhead",
    "data": [21990, 22365, 21987, 22369, 22558, 22987, 23521, 23003, 22756, 23112, 22987, 22897]
}];
    str_json=json.dumps(json_input)
    #print str_json

    total_like_json=get_business_total_like()

    print total_like_json

    return render_template('chartTest.html', str_json=total_like_json)


@app.route('/business', methods=['GET', 'POST'])
def get_business():
    bus_list=get_all_business()
    print bus_list
    bus_list=json.loads(bus_list,"utf-8")
    return render_template('business.html', all_business=bus_list)

@app.route('/onebusiness', methods=['GET'])
def get_one_business():
    if request.method == 'GET':
        query_string=request.args.get('business')
        if query_string is None:
        # session['fb_posts'] = get_totalpost(name,days)
            return render_template('500.html'), 500
        else:
            if not query_string.startswith("'"):
                query_string="'" + query_string + "'"
            like_json=get_business_summary(query_string)
            post_json = get_fb_post_summary(query_string)

            post_shared_json = get_fb_post_shared_summary(query_string)

            print post_shared_json

            post_comment_json = get_fb_post_comment_summary(query_string)

            post_sentiment_json = get_fb_post_sentiment_summary(query_string)

            print post_sentiment_json

            return render_template('BusinessAnalysis.html',business=query_string, str_json=like_json,
                                   str_post_json=post_json,
                                   str_post_shared_json=post_shared_json,str_post_commented_json=post_comment_json,
                                   str_post_sentiment=post_sentiment_json)


@app.route('/comparebusiness', methods=['GET'])
def get_compare_business():
    if request.method == 'GET':
        query_string=request.args.get('business')
        if query_string is None:
        # session['fb_posts'] = get_totalpost(name,days)
            return render_template('500.html'), 500
        else:
            if not query_string.startswith("'"):
                query_string="'" + query_string + "'"
            post_json=get_fb_total_post_compare(query_string)
            like_json = get_fb_total_like_compare(query_string)
            comment_json = get_fb_total_comment_compare(query_string)

            sentiment_json = get_fb_total_sentiment_compare(query_string)

            return render_template('BusinessCompareAnalysis.html',business=query_string, str_json=post_json,
                                   like_json=like_json,
                                   comment_json=comment_json,
                                   sentiment_json=sentiment_json
                                   )

@app.route('/compareTwitterbusiness', methods=['GET'])
def get_compare_twitter_business():
    if request.method == 'GET':
        query_string=request.args.get('business')
        if query_string is None:
        # session['fb_posts'] = get_totalpost(name,days)
            return render_template('500.html'), 500
        else:
            if not query_string.startswith("'"):
                query_string="'" + query_string + "'"
            post_json=get_twitter_total_post_compare(query_string)
            like_json = get_twitter_total_like_compare(query_string)
            comment_json = get_twitter_total_comment_compare(query_string)

            sentiment_json = get_twitter_total_sentiment_compare(query_string)

            return render_template('BusinessTwitterCompareAnalysis.html',business=query_string, str_json=post_json,
                                   like_json=like_json,
                                   comment_json=comment_json,
                                   sentiment_json=sentiment_json
                                   )


@app.route('/twitterbusiness', methods=['GET'])
def get_one_twitter_business():
    if request.method == 'GET':
        query_string = request.args.get('business')
        if query_string is None:
            return render_template('500.html'), 500
        else:
            if not query_string.startswith("'"):
                query_string = "'" + query_string + "'"
            like_json = get_twitter_business_summary(query_string)

            post_json = get_twitter_post_summary(query_string)

            print post_json
            post_shared_json = get_twitter_post_shared_summary(query_string)

            print post_shared_json

            post_comment_json = get_twitter_post_comment_summary(query_string)

            print post_comment_json

            return render_template('TwitterBusinessAnalysis.html', business=query_string, str_json=like_json,str_post_json=post_json,
                                   str_post_shared_json=post_shared_json,str_post_commented_json=post_comment_json)


@app.route('/one', methods=['GET', 'POST'])
def one():
    form = NameForm()
    if form.validate_on_submit():
        session['name'] = form.name.data
        return redirect(url_for('start'))
    return render_template('one.html', form=form, name=session.get('name'), days=session.get('days'))


@app.route('/start', methods=['GET', 'POST'])
def start():
    name = session['name']
    # days = session['days']
    # social_network = session['social_network']
    b_n = [item[1] for item in business_list if item[0] == name]
    b_n = str(b_n[0]).strip('[]')
    form = StartForm()
    if form.validate_on_submit():
        session['days'] = form.days.data
        session['social_network'] = form.social_network.data
        return redirect(url_for('download'))
    return render_template('start.html', form=form, name=b_n)


@app.route('/download', methods=['GET', 'POST'])
def download():
    name = session['name']
    days = session['days']
    # get_totalpost(name,days)
    social_network = session['social_network']
    s_n = [item[1] for item in social_network_list if item[0] == social_network]
    s_n = str(s_n[0]).strip('[]')
    b_n = [item[1] for item in business_list if item[0] == name]
    b_n = str(b_n[0]).strip('[]')
    form = SelectAnalysis()
    if request.method == 'POST':
        session['analysis_type'] = form.analysis_type.data
        # session['fb_posts'] = get_totalpost(name,days)

        return redirect(url_for('analysis'))
    elif request.method == 'GET':
        return render_template('download.html',
                               form=form,
                               name=b_n,
                               days=days,
                               social_network=s_n)


@app.route('/analysis')
def analysis():
    analysis_type = session['analysis_type']
    name = session['name']
    days = session['days']
    s_n = [item[1] for item in social_network_list if item[0] == session['social_network']]
    s_n = str(s_n[0]).strip('[]')
    b_n = [item[1] for item in business_list if item[0] == session['name']]
    b_n = str(b_n[0]).strip('[]')
    form = SelectAnalysis()
    analysis_result = "TEST RESULTS"
    if session['analysis_type'] == 'overview':
        return render_template('charts_fb_bmw.html')
    if session['analysis_type'] == 'mn':
        return render_template('most_negative.html')
    if session['analysis_type'] == 'mc':
        return render_template('most_comments.html')
    if session['analysis_type'] == 'mp':
        return render_template('most_positive.html')
    return render_template('analysis_results.html',
                           name=b_n,
                           days=session['days'],
                           social_network=s_n,
                           analysis_type=analysis_type,
                           analysis_result=analysis_result)

@app.route('/markets')
def markets():
    scope = session['scope']
    if scope == 'market_fb':
        return render_template('charts_market_fb.html',
                               image_width_small=image_width_small,
                               image_height_small=image_height_small,
                               image_width_large=image_width_large,
                               image_height_large=image_height_large, )
    if scope == 'market_tw':
        return render_template('charts_market_tw.html',
                               image_width_small=image_width_small,
                               image_height_small=image_height_small,
                               image_width_large=image_width_large,
                               image_height_large=image_height_large, )
    return redirect(url_for('main_menu'))


@app.route('/cluster', methods=['GET', 'POST'])
def cluster():
    form = SelectCluster()
    if request.method == 'POST':
        session['cluster_business'] = form.cluster_business.data
        # session['fb_posts'] = get_totalpost(name,days)
        return redirect(url_for('cluster_selection'))
    elif request.method == 'GET':
        return render_template('cluster_selection.html',
                               form=form)


@app.route('/cluster_selection')
def cluster_selection():
    cluster_business = session['cluster_business']
    if cluster_business == 'walmart':
        return render_template('cluster_walmart.html')
    if cluster_business == 'dunkin':
        return render_template('cluster_dunkin.html')
    return redirect(url_for('cluster'))

if __name__ == '__main__':
  manager.run()


@app.route('/countme/<input_str>')
def count_me(input_str):
    return input_str



@app.route('/charts')
def charts():
    scope = session['scope']
    if scope == 'all_fb':
        return render_template('charts_fb.html',
                               image_width_small=image_width_small,
                               image_height_small=image_height_small,
                               image_width_large=image_width_large,
                               image_height_large=image_height_large, )
    if scope == 'all_tw':
        return render_template('charts_tw.html',
                               image_width_small=image_width_small,
                               image_height_small=image_height_small,
                               image_width_large=image_width_large,
                               image_height_large=image_height_large, )
    return redirect(url_for('main_menu'))

@app.route('/networks')
def networks():
    return render_template('charts_fb_v_tw.html')
